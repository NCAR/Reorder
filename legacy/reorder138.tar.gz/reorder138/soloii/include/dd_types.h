#ifndef DD_TYPES_H
#define DD_TYPES_H

typedef   unsigned int   uint4;
typedef   int   int4;
typedef float float4;

#ifndef _TMS320C6X
typedef unsigned long long uint8;
#endif

#endif /* DD_TYPES_H */
