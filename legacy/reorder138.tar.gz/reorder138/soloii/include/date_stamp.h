static char *sii_date_stamp = "01/29/07  253";
