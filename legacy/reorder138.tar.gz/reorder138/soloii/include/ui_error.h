/* $Id: ui_error.h 2 2002-07-02 14:57:33Z oye $ */
